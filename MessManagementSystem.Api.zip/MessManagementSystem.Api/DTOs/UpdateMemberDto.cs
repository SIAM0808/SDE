namespace MessManagementSystem.Api.DTOs;

public class UpdateMemberDto
{
    public string Name { get; set; } = string.Empty;

    public string Phone { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;
}